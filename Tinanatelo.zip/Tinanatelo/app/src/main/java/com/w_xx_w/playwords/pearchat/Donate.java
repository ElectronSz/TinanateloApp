package com.w_xx_w.playwords.pearchat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Playwords on 5/17/2017.
 */

public class Donate extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donate);
        //Toast.makeText(getApplicationContext(), "Watch out for my EP [WorldwiseWords] dropping late June", Toast.LENGTH_SHORT).show();
    }
}
