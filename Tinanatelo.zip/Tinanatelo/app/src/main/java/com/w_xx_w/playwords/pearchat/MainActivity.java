package com.w_xx_w.playwords.pearchat;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by Playwords on 5/15/2017.
 */

public class MainActivity extends AppCompatActivity implements ListView.OnItemClickListener {
    ListView main_list_view;
    String[] last_name_array;

    Calendar cal = Calendar.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(getApplicationContext(),"Tinanatelo App welcome you: "+sayGreetings(),Toast.LENGTH_LONG).show();
        last_name_array = getResources().getStringArray(R.array.surname_name);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,R.layout.simple_item,R.id.itemName,last_name_array);

        main_list_view = (ListView) findViewById(R.id.listView2);

        main_list_view.setAdapter(arrayAdapter);
        main_list_view.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {

        //on item click open [DisplayItemContent Activity]
        Intent intent = new Intent(getApplicationContext(),DisplayItemContent.class);

        //inject useful data to Activity
        intent.putExtra("id",""+position);
        intent.putExtra("surname",""+adapter.getItemAtPosition(position));

        //launch new activity
        startActivity(intent);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.share) {
            shareAppLink();
            return true;
        }

        if (id == R.id.contact) {
            Intent integer_contact = new Intent(this,Contact.class);
            this.startActivity(integer_contact);
            return true;
        }

        if (id == R.id.about) {
            Intent integer_about = new Intent(this,About.class);
            this.startActivity(integer_about);
            return true;
        }
        if (id == R.id.terms) {
            Intent integer_terms = new Intent(this,Terms.class);
            this.startActivity(integer_terms);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        exitAppWithDialog();

    }

    private void shareAppLink(){
        Intent share_intent = new Intent(Intent.ACTION_SEND);
        share_intent.setType("text/plain");
        share_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT);

        share_intent.putExtra(Intent.EXTRA_TITLE,"[Tinanatelo App] by Mvelo and Bonkhe");
        share_intent.putExtra(Intent.EXTRA_SUBJECT,"Just download this awesome application");
        share_intent.putExtra(Intent.EXTRA_TEXT,"[Tinanatelo App] by Mvelo and Bonkhe\n\n" +
                "With this app you can view all the praises collection of all the surnames found in Swaziland\n\n" +
                "Proudly Swazi!!");
        startActivity(Intent.createChooser(share_intent,"Share Tinanatelo App download link to friends: "));
    }

    public void exitAppWithDialog(){
        AlertDialog.Builder alBuilder = new AlertDialog.Builder(this);
        alBuilder.setMessage("Are you sure you want to exit?");
        alBuilder.setCancelable(false);

        alBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.super.onBackPressed();
            }
        });

        alBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"Thank you for staying with us",Toast.LENGTH_LONG).show();
            }
        });

        alBuilder.create().show();

    }

    public String sayGreetings(){
        Date dt = new Date();
        String shout = "";
        int hours = dt.getHours();
        int minutes = dt.getMinutes();
        int seconds = dt.getSeconds();
        String greet = "Have A Good", evening = "Evening", morning = "Morning",afternoon = "Afternoon",night="Night";

        if (hours>12 && hours<18){
        shout = greet +" "+afternoon;
        }
        else if (hours>0 && hours<12){
            shout = greet+ " "+morning;
        }

        else if (hours>=18 && hours<=20){
            shout = greet +" "+evening;
        }

        else if (hours>20 && hours<=23){
            shout = greet +" "+night;
        }

        else if (hours==00){
            shout = greet+ " Midnight, Consider Sleeping";
        }

        return shout;
    }
}
