package com.w_xx_w.playwords.pearchat;

import android.content.Intent;

import com.daimajia.androidanimations.library.Techniques;
import com.viksaa.sssplash.lib.activity.AwesomeSplash;
import com.viksaa.sssplash.lib.cnst.Flags;
import com.viksaa.sssplash.lib.model.ConfigSplash;

/**
 * Created by Playwords on 5/18/2017.
 */

public class SplashScreen extends AwesomeSplash {

    @Override
    public void initSplash(ConfigSplash configSplash) {

        configSplash.setBackgroundColor(R.color.colorPrimary);
        configSplash.setAnimCircularRevealDuration(4000);
        configSplash.setRevealFlagX(Flags.REVEAL_RIGHT);
        configSplash.setRevealFlagY(Flags.REVEAL_BOTTOM);
        configSplash.setLogoSplash(R.drawable.logo2);
        configSplash.setAnimLogoSplashDuration(5000);
        configSplash.setAnimLogoSplashTechnique(Techniques.RubberBand);
        configSplash.setOriginalHeight(400);
        configSplash.setAnimPathStrokeDrawingDuration(4000);
        configSplash.setPathSplashStrokeSize(4);
        configSplash.setPathSplashFillColor(R.color.colorPrimary);
        configSplash.setAnimPathFillingDuration(5000);
        configSplash.setPathSplashFillColor(R.color.splashBottle);
        configSplash.setTitleSplash("Tinanatelo App");
        configSplash.setTitleTextColor(R.color.strokeColor);
        configSplash.setAnimTitleDuration(5000);
        configSplash.setAnimTitleTechnique(Techniques.SlideInUp);
    }

    @Override
    public void animationsFinished() {
      Intent intent =  new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}
