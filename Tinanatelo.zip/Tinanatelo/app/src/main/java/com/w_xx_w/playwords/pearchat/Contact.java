package com.w_xx_w.playwords.pearchat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Playwords on 5/17/2017.
 */

public class Contact extends AppCompatActivity{

    EditText email;
    EditText subject;
    EditText message;
    Button send_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        //Toast.makeText(getApplicationContext(), "Watch out for my EP [WorldwiseWords] dropping late June", Toast.LENGTH_SHORT).show();

        email = (EditText)findViewById(R.id.email_txt);
        subject = (EditText)findViewById(R.id.subject_txt);
        message = (EditText)findViewById(R.id.message_txt);

        send_email = (Button)findViewById(R.id.email_btn);

        send_email.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (email.getText().toString().isEmpty() || subject.getText().toString().isEmpty()
                        || message.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"Message was not sent, please make sure you" +
                            " filled all fields with valid data",Toast.LENGTH_LONG).show();
                }

                else{
                    Toast.makeText(getApplicationContext(),"Message Sent Successfully!",Toast.LENGTH_LONG).show();
                }
            }
        });

    }


}
