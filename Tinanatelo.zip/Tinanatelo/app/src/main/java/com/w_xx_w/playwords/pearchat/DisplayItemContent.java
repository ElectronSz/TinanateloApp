package com.w_xx_w.playwords.pearchat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.widget.ListView;
import android.widget.TextView;

/**
 * Created by Playwords on 5/15/2017.
 */

public class DisplayItemContent extends AppCompatActivity {
    TextView intent_data;
    ListView obj;
    String[] desc_array;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_content);

        desc_array = getResources().getStringArray(R.array.surname_desc);

        //get content from previous activity
        String id = getIntent().getStringExtra("id");
        String surname = getIntent().getStringExtra("surname");

        //set new frame title to current surname
        setTitle(surname);

        //initialize tex view
        intent_data = (TextView) findViewById(R.id.textView);

        //parse string to int
        int x_id = Integer.parseInt(id);

        //write data to text view[depending on array's item position]
        intent_data.setText(desc_array[x_id]);

    }

}
